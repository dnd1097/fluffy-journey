# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
from dataiku import spark as dkuspark
from pyspark import SparkContext
from pyspark.sql import SQLContext

sc = SparkContext.getOrCreate()
sqlContext = SQLContext(sc)

# Read recipe inputs
LOAN_DATA_joined = dataiku.Dataset("LOAN_DATA_joined")
spark_df = dkuspark.get_dataframe(sqlContext, LOAN_DATA_joined)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
spark_df.show(5)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
spark_df.count()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
spark_df.select('EARLIEST_CR_LINE').show(4)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
spark_df.select('FUNDED_AMNT').show(4)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Add column from existing column
spark_df = spark_df.withColumn("FUNDED_AMNT_percent", spark_df.FUNDED_AMNT/100)
### no push down here

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
spark_df.show(2)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# List of columns to drop

cols_to_drop =["ZIP_CODE","ISSUE_DATE_PARSED","FUNDED_AMNT"]

# drop the columns
spark_df=spark_df.drop(*cols_to_drop)
## no push down

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Compute recipe outputs from inputs
# TODO: Replace this part by your actual code that computes the output, as a SparkSQL dataframe
#LOAN_DATA_TEST_SPARK_df = LOAN_DATA_TEST_FE_df # For this sample code, simply copy input to output

# Write recipe outputs
LOAN_DATA_SPARK = dataiku.Dataset("LOAN_DATA_SPARK")
dkuspark.write_with_schema(LOAN_DATA_SPARK, spark_df)